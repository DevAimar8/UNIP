package com.example.unip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
