import 'package:flutter/material.dart';

/// Pantalla del chatbot interactivo.
class ChatbotScreen extends StatelessWidget {
  const ChatbotScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chatbot'),
        backgroundColor: Colors.blue[800],
        elevation: 2.0,
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Habla con UNIP y descubre tu futuro:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: const [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: ChatBubble(
                      text: 'Hola, ¿en qué puedo ayudarte?',
                      isBot: true,
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ChatBubble(
                      text: 'Quiero saber qué carrera elegir.',
                      isBot: false,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
            color: Colors.white,
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Escribe aquí...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {},
                  child: const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Widget para burbujas de chat.
class ChatBubble extends StatelessWidget {
  final String text;
  final bool isBot;

  const ChatBubble({
    required this.text,
    required this.isBot,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      padding: const EdgeInsets.all(12.0),
      decoration: BoxDecoration(
        color: isBot ? Colors.blue[100] : Colors.blue[800],
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isBot ? Colors.black : Colors.white,
          fontSize: 16,
        ),
      ),
    );
  }
}
