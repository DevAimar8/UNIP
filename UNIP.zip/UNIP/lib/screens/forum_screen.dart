import 'package:flutter/material.dart';

/// Pantalla del foro para discusión y experiencias de estudiantes.
class ForumScreen extends StatelessWidget {
  const ForumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Foro Estudiantil'),
        backgroundColor: Colors.blue[800],
        elevation: 2.0,
      ),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              'Comparte tus experiencias y aprende de otros estudiantes:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16.0),
              children: List.generate(
                5,
                (index) => Card(
                  elevation: 3,
                  margin: const EdgeInsets.only(bottom: 10.0),
                  child: ListTile(
                    title: Text(
                      'Estudiante ${index + 1}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: const Text(
                        'Compartiendo mi experiencia en Ingeniería de Software...'),
                    trailing: const Icon(Icons.arrow_forward),
                    onTap: () {},
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {}, // Acción para agregar una nueva experiencia
        backgroundColor: Colors.blue[800],
        child: const Icon(Icons.add),
      ),
    );
  }
}
