import 'package:flutter/material.dart';

class CareerChoiceScreen extends StatelessWidget {
  final List<Map<String, String>> careers = [
    {'title': 'Ingeniería Informática', 'description': 'Explora el mundo de la programación y tecnología.'},
    {'title': 'Medicina', 'description': 'Ayuda a salvar vidas y cuida de las personas.'},
    {'title': 'Diseño Gráfico', 'description': 'Crea y diseña arte visual para el mundo.'},
    {'title': 'Derecho', 'description': 'Aboga por la justicia y la legalidad.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Explorar Carreras'),
        backgroundColor: Colors.blue[800],
      ),
      backgroundColor: Colors.white,
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: careers.length,
        itemBuilder: (context, index) {
          return _buildCareerCard(careers[index]);
        },
      ),
    );
  }

  Widget _buildCareerCard(Map<String, String> career) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Icon(Icons.school, size: 40, color: Colors.blueAccent),
        title: Text(
          career['title']!,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        subtitle: Text(
          career['description']!,
          style: const TextStyle(fontSize: 14, color: Colors.black54),
        ),
        trailing: Icon(Icons.arrow_forward_ios, color: Colors.blueAccent),
        onTap: () {
          // Navegar a más detalles sobre la carrera
        },
      ),
    );
  }
}
