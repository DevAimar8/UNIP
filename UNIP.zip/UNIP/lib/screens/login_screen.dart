import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../widgets/terms_dialog.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _termsAccepted = false; // Estado del checkbox
  final GoogleSignIn _googleSignIn = GoogleSignIn(); // Instancia para Google Sign-In

  // Función para manejar el inicio de sesión con Google
  Future<void> _handleGoogleSignIn() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser != null) {
        // Si el inicio de sesión fue exitoso
        print('Nombre del usuario: ${googleUser.displayName}');
        print('Correo electrónico: ${googleUser.email}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Bienvenido, ${googleUser.displayName}!'),
            backgroundColor: Colors.green,
          ),
        );
        // Navega a la pantalla principal después del inicio de sesión
        Navigator.pushNamed(context, '/home');
      }
    } catch (error) {
      // Manejamos los errores
      print('Error al iniciar sesión con Google: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Error al iniciar sesión con Google.'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Diálogo de términos y condiciones
  void _showTermsDialog() async {
    showDialog(
      context: context,
      builder: (context) => TermsDialog(
        onAccept: (bool accepted) {
          setState(() {
            _termsAccepted = accepted; // Actualizar el estado del checkbox
          });

          if (!accepted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Debes aceptar los términos y condiciones para continuar.'),
                backgroundColor: Colors.red,
              ),
            );
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 40.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Logo
              Image.asset(
                'assets/logo.png', // Ruta de tu logo
                height: 100,
              ),
              const SizedBox(height: 20),
              const Text(
                '¡A un paso de ser muy top!',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),

              // Botón de Google
              ElevatedButton.icon(
                onPressed: _termsAccepted
                    ? _handleGoogleSignIn
                    : _showTermsDialog, // Llama al método de Google Sign-In
                icon: const Icon(Icons.g_mobiledata),
                label: const Text('Iniciar sesión con Google'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                  textStyle: const TextStyle(fontSize: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 15),

              // Checkbox de términos y condiciones
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Checkbox(
                    value: _termsAccepted,
                    onChanged: (value) {
                      if (value == true) {
                        _showTermsDialog();
                      } else {
                        setState(() {
                          _termsAccepted = false;
                        });
                      }
                    },
                  ),
                  GestureDetector(
                    onTap: _showTermsDialog,
                    child: const Text(
                      'Acepto los términos y condiciones',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 14,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Texto para registro con navegación a RegisterScreen
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/register'); // Navega a la pantalla de registro
                },
                child: const Text(
                  '¿No estás registrado? Regístrate aquí.',
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 14,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
