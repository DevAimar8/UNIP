import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart'; // Paquete para manejar el inicio de sesión con Google

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GoogleSignIn _googleSignIn = GoogleSignIn(); // Instancia de GoogleSignIn para autenticar al usuario

  // Función para manejar el inicio de sesión con Google
  Future<void> _handleSignIn() async {
    try {
      await _googleSignIn.signIn(); // Intenta iniciar sesión con la cuenta de Google
      // Si el login es exitoso, se redirige a la pantalla principal
      Navigator.pushReplacementNamed(context, '/home'); 
    } catch (error) {
      print("Error al iniciar sesión: $error"); // Muestra un error si algo sale mal
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50], // Color de fondo de la pantalla
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32.0), // Espaciado horizontal
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Centra los elementos verticalmente
            children: <Widget>[
              // Aquí deberías poner tu logo de la app
              // Icono de la aplicación (en lugar de la imagen)
            const Icon(
              Icons.school,  // Usamos el ícono de la escuela
              color: Colors.white,  // Color blanco para el ícono
              size: 100,  // Tamaño del ícono
            ),
              const SizedBox(height: 50), // Espacio entre el logo y el texto
              Text(
                'Bienvenido a UNIP',
                style: TextStyle(
                  fontSize: 30.0, // Tamaño de fuente
                  fontWeight: FontWeight.bold, // Negrita
                  color: Colors.blue[800], // Color del texto
                ),
              ),
              const SizedBox(height: 30), // Espacio entre el texto y el botón
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[800], // Color del botón
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Bordes redondeados
                  ),
                ),
                onPressed: _handleSignIn, // Cuando se presiona el botón, llama a la función _handleSignIn
                child: const Row(
                  mainAxisSize: MainAxisSize.min, // Ajusta el tamaño del botón al contenido
                  children: <Widget>[
                    Icon(Icons.login, color: Colors.white), // Icono de login
                    SizedBox(width: 10), // Espacio entre el icono y el texto
                    Text(
                      'Iniciar sesión con Google',
                      style: TextStyle(color: Colors.white), // Texto blanco en el botón
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
