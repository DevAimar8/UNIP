import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa de Universidades'),
        backgroundColor: Colors.blue[800],
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: LatLng(40.416775, -3.703790), // Coordenadas de España
              zoom: 6,
            ),
            markers: _createMarkers(),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: _buildFilterPanel(context),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterPanel(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Filtros:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.filter_list),
                  label: const Text('Carreras'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                ),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.location_city),
                  label: const Text('Región'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Set<Marker> _createMarkers() {
    return {
      Marker(
        markerId: MarkerId('1'),
        position: LatLng(40.416775, -3.703790), // Ejemplo: Madrid
        infoWindow: InfoWindow(title: 'Universidad Complutense de Madrid'),
      ),
      Marker(
        markerId: MarkerId('2'),
        position: LatLng(41.385063, 2.173404), // Ejemplo: Barcelona
        infoWindow: InfoWindow(title: 'Universitat de Barcelona'),
      ),
    };
  }
}
