import 'package:flutter/material.dart';
import 'map_screen.dart';
import 'chatbot_screen.dart';
import 'forum_screen.dart';
import 'career_choice_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50], // Fondo azul claro
      appBar: AppBar(
        title: const Text('UNIP'),
        centerTitle: true,
        backgroundColor: Colors.blue[800],
        elevation: 2.0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '¡Bienvenido a UNIP!',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Descubre tu futuro con nuestras herramientas:',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  _buildOptionCard(
                    context,
                    title: 'Mapa',
                    icon: Icons.map,
                    color: Colors.blue,
                    onTap: () {
                      _navigateWithSlideTransition(
                        context,
                         MapScreen(),
                        beginOffset: const Offset(0.0, 1.0), // Desde abajo
                      );
                    },
                  ),
                  _buildOptionCard(
                    context,
                    title: 'Chatbot',
                    icon: Icons.chat,
                    color: const Color.fromARGB(255, 254, 194, 42),
                    onTap: () {
                      _navigateWithSlideTransition(
                        context,
                        const ChatbotScreen(),
                        beginOffset: const Offset(1.0, 0.0), // Desde la derecha
                      );
                    },
                  ),
                  _buildOptionCard(
                    context,
                    title: 'Foro',
                    icon: Icons.forum,
                    color: Colors.green,
                    onTap: () {
                      _navigateWithSlideTransition(
                        context,
                        const ForumScreen(),
                        beginOffset: const Offset(-1.0, 0.0), // Desde la izquierda
                      );
                    },
                  ),
                  _buildOptionCard(
                    context,
                    title: 'Explorar Carreras',
                    icon: Icons.school,
                    color: Colors.orange,
                    onTap: () {
                      _navigateWithSlideTransition(
                        context,
                         CareerChoiceScreen(),
                        beginOffset: const Offset(0.0, -1.0), // Desde arriba
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Crea una tarjeta para las opciones del menú
  Widget _buildOptionCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.8),
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 6,
              offset: Offset(2, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.white),
            const SizedBox(height: 10),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Navega con una transición personalizada
  void _navigateWithSlideTransition(
    BuildContext context,
    Widget screen, {
    required Offset beginOffset,
  }) {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => screen,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          var tween = Tween(begin: beginOffset, end: Offset.zero)
              .chain(CurveTween(curve: Curves.ease));
          var offsetAnimation = animation.drive(tween);

          return SlideTransition(position: offsetAnimation, child: child);
        },
      ),
    );
  }
}
