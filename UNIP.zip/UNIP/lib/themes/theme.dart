import 'package:flutter/material.dart';

ThemeData appTheme() {
  return ThemeData(
    primaryColor: Colors.blue[800], // Azul oscuro
    scaffoldBackgroundColor: Colors.white,  // Fondo blanco

    // Actualización de 'accentColor' a 'colorScheme.secondary'
    colorScheme: const ColorScheme.light(
      secondary: Colors.yellow,      // Amarillo
    ),

    // Actualización del tema de texto
    textTheme: TextTheme(
      // Nuevas propiedades de texto según Flutter 2.x+
      bodyLarge: const TextStyle(color: Colors.black),  // Cambiado de bodyText1
      bodyMedium: TextStyle(color: Colors.grey[600]),  // Cambiado de bodyText2
      titleLarge: const TextStyle(color: Colors.white, fontSize: 20),  // Cambiado de headline6
    ),

    // Tema de AppBar
    appBarTheme: AppBarTheme(
      color: Colors.blue[800],
      elevation: 0,
      // Asegurar que el texto del AppBar esté blanco y bien dimensionado
      titleTextStyle: const TextStyle(color: Colors.white, fontSize: 20),
    ),
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.blue[800],   // Color de los botones
      textTheme: ButtonTextTheme.primary,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: Colors.blue[800], // Color de los botones flotantes
    ),
    /// Tema para botones elevados.
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.blue[700], // Color de fondo del botón.
        foregroundColor: Colors.white, // Color del texto del botón.
        textStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ), // Estilo de texto de los botones.
      ),
    ),
  );
}
