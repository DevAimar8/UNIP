import 'package:flutter/material.dart';

class TermsDialog extends StatelessWidget {
  final Function(bool) onAccept; // Callback para devolver si el usuario acepta

  const TermsDialog({Key? key, required this.onAccept}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        'Términos y condiciones',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      content: const SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Al usar esta aplicación, aceptas los siguientes términos:\n\n'
              '1. Tu información será almacenada y procesada de acuerdo con nuestra política de privacidad.\n\n'
              '2. No se permite el uso indebido de la plataforma.\n\n'
              '3. La información proporcionada en esta app es orientativa.\n\n'
              'Consulta la política de privacidad completa en nuestro sitio web.',
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(height: 10),
            Text(
              '¿Aceptas estos términos?',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            // Usuario no acepta
            onAccept(false);
            Navigator.pop(context);
          },
          child: const Text(
            'No aceptar',
            style: TextStyle(color: Colors.red),
          ),
        ),
        ElevatedButton(
          onPressed: () {
            // Usuario acepta
            onAccept(true);
            Navigator.pop(context);
          },
          child: const Text('Aceptar'),
        ),
      ],
    );
  }
}
