import 'package:flutter/material.dart';

/// Un widget reutilizable para la barra de navegación inferior.
/// Permite cambiar entre las secciones principales de la app.
class BottomNavBar extends StatelessWidget {
  final int currentIndex; // Índice actual seleccionado
  final Function(int) onTap; // Callback cuando se selecciona un ítem

  const BottomNavBar({
    required this.currentIndex,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex, // Define el ítem activo
      onTap: onTap, // Acción al tocar un ítem
      type: BottomNavigationBarType.fixed, // Estilo fijo para mantener visibilidad
      selectedItemColor: Colors.blue[800], // Color del ítem seleccionado
      unselectedItemColor: Colors.grey, // Color de los ítems no seleccionados
      items: const [
        // Ítem de inicio
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Inicio',
        ),
        // Ítem del mapa
        BottomNavigationBarItem(
          icon: Icon(Icons.map),
          label: 'Mapa',
        ),
        // Ítem del chatbot
        BottomNavigationBarItem(
          icon: Icon(Icons.chat),
          label: 'Chatbot',
        ),
        // Ítem del foro
        BottomNavigationBarItem(
          icon: Icon(Icons.forum),
          label: 'Foro',
        ),
      ],
    );
  }
}
