import 'package:flutter/material.dart';
import 'themes/theme.dart';  // Importa el archivo theme.dart
import 'screens/home_screen.dart';  // Importa tus pantallas

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UNIP',
      theme: appTheme(),  // Aplica el tema
      home: HomeScreen(),  // Pantalla principal
    );
  }
}
